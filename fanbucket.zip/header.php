<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<title>fanbucket</title>

	<!-- bootstrap icon -->
	<link rel="stylesheet" href="./node_modules/bootstrap-icons/font/bootstrap-icons.css">

	<!-- fancybox -->
	<!-- <link rel="stylesheet" href="./css/fancybox/fancybox.min.css"> -->

	<!-- moments -->
	<!-- demo styles -->
	<link rel="stylesheet" href="./node_modules/zuck.js/demo/style.css">
	<!-- lib styles -->
	<link rel="stylesheet" href="./node_modules/zuck.js/dist/zuck.min.css">

	<!-- lib skins -->
	<link rel="stylesheet" href="./node_modules/zuck.js/dist/skins/snapgram.css">
	

	<link rel="stylesheet" href="./node_modules/datetime/css/tail.datetime-harx-light.css">



	<!-- slick -->
	<link rel="stylesheet" href="./css/slick/slick-theme.css">
	<link rel="stylesheet" href="./css/slick/slick.css">

	<!-- animate -->
	<link
	rel="stylesheet"
	href="./node_modules/animate.css/animate.min.css"
	/>

	<!-- bootstrap -->
	<link rel="stylesheet" href="./css/bootstrap/css/bootstrap-grid.min.css">
	<link rel="stylesheet" href="./css/bootstrap/css/bootstrap-reboot.min.css">
	<link rel="stylesheet" href="./css/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/animate.css">
	<link rel="stylesheet" href="./css/style.css">
	<!-- style -->
	<!-- <link rel="stylesheet" href="./css/style.css"> -->
	<?php 
	if(  $currentpage== 'other'){
		echo '<link rel="stylesheet" href="./css/otherstyle.css">'; 
	}
	?>

</head>
<body >

	
