<div class="tost-wrapper">
  <div class="toast  hide" role="alert" >
    <div class="toast-header">
      <strong class="mr-auto">New Notification</strong>
      <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="toast-body">
     <p class="para">You are following Tonny Ray. <a href="#" class="link small">Click Here</a></p> 

   </div>
 </div>
</div>