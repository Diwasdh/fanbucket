<footer>
	<canvas id="thumblain"></canvas>
	<video id="fakeVideo">
		<source src="" type="video/mp4" >
	</video>
</footer>


<?php 
	include './template/modal--post.php'
 ?>
 <?php 
	include './template/notification-toast.php'
 ?>




<!--jquery  -->
<script type="text/javascript" src="./js/jquery.js"></script>



<!-- fancybox -->
<!-- <script type="text/javascript" src="./css/fancybox/jquery.fancybox.min.js"></script> -->
<!-- owl -->
<script type="text/javascript" src="./css/slick/slick.min.js"></script>

<script src="./js/hammerjs.js"></script>
<!-- bootstrap -->
<script type="text/javascript" src="./css/bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="./css/bootstrap/js/bootstrap.min.js"></script>

<script src="./node_modules/datetime/js/tail.datetime.js" type="text/javascript"></script>

<!-- commom js -->
<script type="text/javascript" src="./js/commonjs.js"></script>



